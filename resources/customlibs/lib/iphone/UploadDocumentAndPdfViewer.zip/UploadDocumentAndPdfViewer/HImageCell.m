//
//  HCapturedGalleryViewController.h
//  Healogics
//
//  Created by Healogics on 12/04/17.
//  Copyright © 2017 Cognizant. All rights reserved.
//

#import "HImageCell.h"

@implementation HImageCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.imgPhoto.backgroundColor=[UIColor colorWithRed:234.0/255.0 green:234.0/255.0 blue:234.0/255.0 alpha:1.0];
    [self.imgPhoto.layer setBorderWidth:2];
    [self.imgPhoto.layer setBorderColor:[[UIColor clearColor] CGColor]];
    
    [self.btnDelete.layer setCornerRadius:15.0];
}

// method to delete selected cell
-(IBAction)btnDeleteCapturedPhoto:(id)sender
{
//    NSLog(@"----- Clicked on delete captured photo button ----- %li",(long)self.tag);
    [self.delegate deleteSelectedCell:self.tag];
    
}

@end
