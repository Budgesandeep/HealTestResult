//
//  Cache.h
//  VMAppWithKonylib
//
//  Created by Healogics on 16/06/17.
//
//

#import <Foundation/Foundation.h>
#import "HConstants.h"

@interface HCache : NSObject

@property (weak, nonatomic)  NSString *strStoredLargeImagePath , *strStoredSmallImagePath;
@property (weak, nonatomic)  NSArray *paths, *arrCachedfiles;
@property (weak, nonatomic)  NSFileManager *fileManager;
    
+ (id)sharedManager;
-(NSString*)checkAndGetMeCacheDirectoryPath : (NSString*)type;
- (void)cacheImage: (NSString *)ImageURLString andImage:(UIImage*)img type:(NSString*)type;
-(NSMutableArray*)getAllCachedImages;
-(void)clearAllCachedImages;
-(void)deleteSelectedImageFromCache:(NSString*)strPath;
-(void)clearAllCachedSmallImages;
    
@end
