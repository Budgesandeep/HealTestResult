//
//  UINavigationController+deviceOrientation.h
//  VMAppWithKonylib
//
//  Created by Healogics on 17/05/17.
//
//

#import <UIKit/UIKit.h>

@interface UINavigationController (deviceOrientation)

-(BOOL)shouldAutorotate;
-(UIInterfaceOrientationMask)supportedInterfaceOrientations;
-(UIInterfaceOrientation)preferredInterfaceOrientationForPresentation;

@end
