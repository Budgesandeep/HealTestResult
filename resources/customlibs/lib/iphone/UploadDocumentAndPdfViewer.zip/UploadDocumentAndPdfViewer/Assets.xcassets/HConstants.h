//
//  TSConstants.h
//  VMAppWithKonylib
//
//  Created by Healogics on 14/11/16.
//
//

//#ifndef TSConstants_h
//#define TSConstants_h
//
//
//#endif /* TSConstants_h */



#define maxCompressionLevel 0
#define strSmallTxt @"Small"
#define strLargeTxt @"Large"
#define kStoryboardMain @"Main"
#define kPdfViewer @"PDFViewer"
#define kCapturedGalleryVC @"HCapturedGalleryVC"
#define kDeviceOSVersion  [[[UIDevice currentDevice] systemVersion] floatValue]
#define kDeviceType UI_USER_INTERFACE_IDIOM()


