//
//  ViewController.m
//  VMAppWithKonylib
//
//  Created by Healogics on 27/09/16.
//  Copyright © 2016 Cognizant. All rights reserved.
//

#import "HCaptureViewController.h"
#import <AssetsLibrary/AssetsLibrary.h>
#import <AVFoundation/AVFoundation.h>
#import <MobileCoreServices/MobileCoreServices.h>
#import "HCapturedGalleryViewController.h"

@interface HCaptureViewController () <UINavigationControllerDelegate,UIImagePickerControllerDelegate,AVCapturePhotoCaptureDelegate>

@property (weak, nonatomic) AVCaptureVideoPreviewLayer *previewLayer;
@property (weak, nonatomic) AVCapturePhotoOutput *avPhotoOutput;
@property (strong, nonatomic) AVCaptureStillImageOutput *stillImageOutput;
@property (weak, nonatomic) AVCaptureSession *session;
@property (weak, nonatomic) AVCaptureConnection *previewLayerConnection;
@property (weak, nonatomic) IBOutlet UIView *photoView;
@property (weak, nonatomic) IBOutlet UIButton *btnCapture;
@property (weak, nonatomic) IBOutlet UIButton *btnCancelCamera;
@property (weak, nonatomic) UIImage *image,*imgfinalCaptured;
@property (weak, nonatomic) IBOutlet UIView *vwUsePhoto;
@property (weak, nonatomic) IBOutlet UIView *vwUsePhotoFooter;
@property (weak, nonatomic) IBOutlet UIView *vwPhotoFooter;
@property (weak, nonatomic) IBOutlet UIImageView *imgCaptured;
@property (weak, nonatomic) NSString *strDate;
@property (weak, nonatomic) HCapturedGalleryViewController *hCaptureVC ;
@property (nonatomic) UIImageOrientation *imageOrientation;
@property (retain, nonatomic) IBOutlet NSLayoutConstraint *tralingConstraintofCancel;
@property (retain, nonatomic) IBOutlet NSLayoutConstraint *leadingConstraintofRetake;
@property (retain, nonatomic) IBOutlet NSLayoutConstraint *trailingConstraintofUsePhoto;
@property (nonatomic) NSInteger initialOrientation;
@end

@implementation HCaptureViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //Set Font & text color for ViewController's navigation bar Title
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor darkGrayColor], NSFontAttributeName:[UIFont fontWithName:@"Calibri-bold" size:20]}];
    [[UIBarButtonItem appearance] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIFont fontWithName:@"Calibri" size:18.0],NSFontAttributeName, nil] forState:UIControlStateNormal];
    
    [[HCache sharedManager] clearAllCachedImages];
    
    self.btnCapture.layer.cornerRadius =  self.btnCapture.frame.size.width/2;
    self.vwUsePhoto.hidden=YES;
    self.vwUsePhotoFooter.hidden=YES;
    self.btnCapture.hidden=NO;
    self.btnCancelCamera.hidden=NO;
    self.photoView.hidden = NO;
    
    if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera]){
        self.session = [[AVCaptureSession alloc] init];
        self.session.sessionPreset = AVCaptureSessionPresetHigh;
        AVCaptureDevice *videoDevice = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
        if (videoDevice)
        {
            NSError *error;
            AVCaptureDeviceInput *videoInput = [AVCaptureDeviceInput deviceInputWithDevice:videoDevice error:&error];
            if (!error)
            {
                if ([self.session canAddInput:videoInput])
                {
                    [self.session addInput:videoInput];
                    self.previewLayer = [AVCaptureVideoPreviewLayer layerWithSession:self.session];
                    self.previewLayer.frame = self.view.bounds;
                    [(AVCaptureVideoPreviewLayer *)self.previewLayer  setVideoGravity:AVLayerVideoGravityResizeAspectFill];
                    [self.photoView.layer addSublayer:self.previewLayer];
                    
                    if (kDeviceOSVersion >= 10.0) {
                        self.avPhotoOutput = [[AVCapturePhotoOutput alloc] init];
                        [self.session addOutput:self.avPhotoOutput];
                    }else{
                        self.stillImageOutput = [[AVCaptureStillImageOutput alloc] init];
                        [self.session addOutput:self.stillImageOutput];
                    }
                    
                    
                    self.previewLayerConnection=self.previewLayer.connection;
                    if ([self.previewLayerConnection isVideoOrientationSupported])
                        [self.previewLayerConnection setVideoOrientation:[[UIApplication sharedApplication] statusBarOrientation]];
                    
                    [self.session startRunning];
                }
            }
        }
    }
    
}


-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    if (kDeviceType == UIUserInterfaceIdiomPad) {
        if([UIDevice currentDevice].orientation==4 ){
            self.imageOrientation = UIImageOrientationDown;
            self.initialOrientation = 1;
        }else{
            
            self.imageOrientation = UIImageOrientationUp;
            self.initialOrientation = 0;
        }
        self.tralingConstraintofCancel.constant = 45;
        self.leadingConstraintofRetake.constant = 50;
        self.trailingConstraintofUsePhoto.constant = 50;
    }else{
        self.imageOrientation = UIImageOrientationRight;
        self.initialOrientation = 3;
        self.tralingConstraintofCancel.constant = 5;
        self.leadingConstraintofRetake.constant = 7;
        self.trailingConstraintofUsePhoto.constant = 15;
    }
}


#pragma UINavigationController delegate methods
-(BOOL)shouldAutorotate{
    return NO;
}

-(UIInterfaceOrientationMask)supportedInterfaceOrientations{
    if (kDeviceType == UIUserInterfaceIdiomPad) {
        return UIInterfaceOrientationMaskLandscape;
    }else{
        return UIInterfaceOrientationMaskPortraitUpsideDown;
    }
}

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation
{
    if (kDeviceType == UIUserInterfaceIdiomPad) {
        return (UIInterfaceOrientationLandscapeLeft | UIInterfaceOrientationLandscapeRight);
    }else{
        return UIInterfaceOrientationPortraitUpsideDown;
    }
}

#pragma mark - Method to Capture photo
- (IBAction)stillImageCapture
{
    
    AVAuthorizationStatus authStatus = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
    if(authStatus == AVAuthorizationStatusAuthorized)
    {
        if (kDeviceOSVersion >= 10.0) {
            AVCapturePhotoSettings *avSettings = [AVCapturePhotoSettings photoSettings];
            [self.avPhotoOutput capturePhotoWithSettings:avSettings delegate:self];
        }else{
            AVCaptureConnection *videoConnection = nil;
            for (AVCaptureConnection *connection in self.stillImageOutput.connections)
            {
                for (AVCaptureInputPort *port in [connection inputPorts])
                {
                    if ([[port mediaType] isEqual:AVMediaTypeVideo])
                    {
                        videoConnection = connection;
                        break;
                    }
                }
                if (videoConnection)
                {
                    break;
                }
            }
            [self.stillImageOutput captureStillImageAsynchronouslyFromConnection:videoConnection completionHandler:^(CMSampleBufferRef imageDataSampleBuffer, NSError *error)
             {
                 if(imageDataSampleBuffer)
                 {
                      UIImage *cropped  = nil;
                     @autoreleasepool {
                         NSData *imageData = [AVCaptureStillImageOutput jpegStillImageNSDataRepresentation:imageDataSampleBuffer];
                         cropped = [self formattedImage:imageData];
                         self.imgCaptured.image = cropped;
                         if(self.imgfinalCaptured != nil){
                             self.imgfinalCaptured = nil;
                         }
                         self.imgfinalCaptured = cropped;
                     }

                     dispatch_async(dispatch_get_main_queue(), ^{
                         self.imgCaptured.image = cropped;
                         self.vwUsePhoto.hidden=NO;
                         self.btnCapture.hidden=YES;
                         self.btnCancelCamera.hidden=YES;
                         self.photoView.hidden = YES;
                         self.vwUsePhotoFooter.hidden=NO;
                     });
                 }
             }];
            
        }
    }
}

#pragma mark - AVCapturePhotoCaptureDelegate
-(void)captureOutput:(AVCapturePhotoOutput *)captureOutput didFinishProcessingPhotoSampleBuffer:(CMSampleBufferRef)photoSampleBuffer previewPhotoSampleBuffer:(CMSampleBufferRef)previewPhotoSampleBuffer resolvedSettings:(AVCaptureResolvedPhotoSettings *)resolvedSettings bracketSettings:(AVCaptureBracketedStillImageSettings *)bracketSettings error:(NSError *)error
{
    if (error) {
        NSLog(@"error : %@", error.localizedDescription);
    }
    if (photoSampleBuffer) {
        UIImage *cropped  = nil;
        @autoreleasepool {
            
            NSData *data = [AVCapturePhotoOutput JPEGPhotoDataRepresentationForJPEGSampleBuffer:photoSampleBuffer previewPhotoSampleBuffer:previewPhotoSampleBuffer];
            cropped = [self formattedImage:data];
            self.imgCaptured.image = cropped;
            if(self.imgfinalCaptured != nil){
                self.imgfinalCaptured = nil;
            }
            self.imgfinalCaptured = cropped;
        }
        
        self.vwUsePhoto.hidden=NO;
        self.btnCapture.hidden=YES;
        self.btnCancelCamera.hidden=YES;
        self.photoView.hidden = YES;
        self.vwUsePhotoFooter.hidden=NO;
    }
}

-(UIImage*)formattedImage :(NSData*)data{
    
    UIImage *image =  [UIImage imageWithCGImage:[UIImage imageWithData:data].CGImage scale:1.0f orientation:self.imageOrientation];
    
    CGRect visibleLayerFrame = self.imgCaptured.frame;
    CGRect metaRect = [self.previewLayer metadataOutputRectOfInterestForRect:visibleLayerFrame];
    
    CGSize originalSize = [image size];

    if (kDeviceType==UIUserInterfaceIdiomPhone  && ( [UIDevice currentDevice].orientation != 1|| [UIDevice currentDevice].orientation != 2) ) {
        // For portrait images, swap the size of the image, because
        // here the output image is actually rotated relative to what you see on screen.
        CGFloat temp = originalSize.width;
        originalSize.width = originalSize.height;
        originalSize.height = temp;
    }
    
    
    // metaRect is fractional, that's why we multiply here
    
    CGRect cropRect;
    
    cropRect.origin.x = metaRect.origin.x * originalSize.width;
    cropRect.origin.y = metaRect.origin.y * originalSize.height;
    cropRect.size.width = metaRect.size.width * originalSize.width;
    cropRect.size.height = metaRect.size.height * originalSize.height;
    cropRect = CGRectIntegral(cropRect);
    CGImageRef imageRef = CGImageCreateWithImageInRect([image CGImage], cropRect);
    UIImage *cropped = [UIImage imageWithCGImage:imageRef];
    if (kDeviceType == UIUserInterfaceIdiomPad) {
        if( self.initialOrientation == 1  ){
            cropped = [self imageRotatedByDegrees:cropped deg:180];
        }else{
            if([UIApplication sharedApplication].statusBarOrientation==4){
                cropped = [self imageRotatedByDegrees:cropped deg:180];
            }
        }
    }else{
        cropped = [self imageRotatedByDegrees:cropped deg:90];
    }
    //    self.imgfinalCaptured = cropped;
    return cropped;
}


- (UIImage *)imageRotatedByDegrees:(UIImage*)oldImage deg:(CGFloat)degrees{
    //Calculate the size of the rotated view's containing box for our drawing space
    UIView *rotatedViewBox = [[UIView alloc] initWithFrame:CGRectMake(0,0,oldImage.size.width, oldImage.size.height)];
    CGAffineTransform t = CGAffineTransformMakeRotation(degrees * M_PI / 180);
    rotatedViewBox.transform = t;
    CGSize rotatedSize = rotatedViewBox.frame.size;
    
    //Create the bitmap context
    UIGraphicsBeginImageContext(rotatedSize);
    CGContextRef bitmap = UIGraphicsGetCurrentContext();
    
    //Move the origin to the middle of the image so we will rotate and scale around the center.
    CGContextTranslateCTM(bitmap, rotatedSize.width/2, rotatedSize.height/2);
    
    //Rotate the image context
    CGContextRotateCTM(bitmap, (degrees * M_PI / 180));
    
    //Now, draw the rotated/scaled image into the context
    CGContextScaleCTM(bitmap, 1.0, -1.0);
    CGContextDrawImage(bitmap, CGRectMake(-oldImage.size.width / 2, -oldImage.size.height / 2, oldImage.size.width, oldImage.size.height), [oldImage CGImage]);
    
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newImage;
}


#pragma mark - Methods to navigate back to Kony
//Back to Kony form without uploading images
-(IBAction)btnBackToKonyForm:(id)sender{
    
    [self dismissViewControllerAnimated:NO completion:nil];
    //call kony call back function
    HFFIClass *konyCallBack = [HFFIClass sharedManager];
    [konyCallBack.konyCallBackFunctionName executeWithArguments: nil];
}

- (IBAction)btnRetakePhotoClick:(id)sender {
    self.vwUsePhoto.hidden=YES;
    self.btnCapture.hidden=NO;
    self.btnCancelCamera.hidden=NO;
    self.photoView.hidden = NO;
    self.vwUsePhotoFooter.hidden=YES;
}

- (IBAction)btnUsePhotoClick:(id)sender {
    
    self.strDate=[NSString stringWithFormat:@"%@",[NSDate date]];
    self.strDate = [self.strDate stringByReplacingOccurrencesOfString:@" " withString:@""];
    self.strDate = [self.strDate stringByReplacingOccurrencesOfString:@"-" withString:@""];
    self.strDate = [self.strDate stringByReplacingOccurrencesOfString:@":" withString:@""];
    self.strDate = [self.strDate stringByReplacingOccurrencesOfString:@"+" withString:@""];
    
//    CGSize requiredSize ;
//    if (kDeviceType == UIUserInterfaceIdiomPad) {
//        requiredSize = CGSizeMake(self.imgfinalCaptured.size.width/4, self.imgfinalCaptured.size.height/4);
//    }else{
//        requiredSize = CGSizeMake(self.imgfinalCaptured.size.width/3, self.imgfinalCaptured.size.height/3);
//    }
    
    
    [[HCache sharedManager] cacheImage:[NSString stringWithFormat:@"%@",self.strDate] andImage:[self.imgCaptured.image thumbnailImage:100 transparentBorder:0 cornerRadius:0 interpolationQuality:kCGInterpolationMedium] type:strSmallTxt];
    [[HCache sharedManager] cacheImage:[NSString stringWithFormat:@"%@",self.strDate] andImage:self.imgfinalCaptured type:strLargeTxt];
    self.vwUsePhoto.hidden=YES;
    self.btnCapture.hidden=NO;
    self.btnCancelCamera.hidden=NO;
    self.photoView.hidden = NO;
    
    
    self.hCaptureVC = [self.storyboard instantiateViewControllerWithIdentifier:kCapturedGalleryVC];
    [self.navigationController pushViewController:self.hCaptureVC animated:NO];
    
}

- (IBAction)btnCacelCameraClick:(id)sender {
    
    self.vwUsePhoto.hidden=YES;
    self.btnCapture.hidden=NO;
    self.btnCancelCamera.hidden=NO;
    self.photoView.hidden = NO;
    self.hCaptureVC = [self.storyboard instantiateViewControllerWithIdentifier:kCapturedGalleryVC];
    [self.navigationController pushViewController:self.hCaptureVC animated:NO];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)dealloc {
    [_tralingConstraintofCancel release];
    [_leadingConstraintofRetake release];
    [_trailingConstraintofUsePhoto release];
    [super dealloc];
}
@end
