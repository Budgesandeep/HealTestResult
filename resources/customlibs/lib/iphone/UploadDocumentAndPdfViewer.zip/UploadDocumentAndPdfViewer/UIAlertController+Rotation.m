//
//  UIAlertController+Rotation.m
//  VMAppWithKonylib
//
//  Created by Healogics on 19/06/17.
//
//

#import "UIAlertController+Rotation.h"

@implementation UIAlertController (Rotation)

-(BOOL)shouldAutorotate{
    UIDeviceOrientation orientation = [[UIDevice currentDevice] orientation];
    
    if ( orientation == UIDeviceOrientationPortrait | orientation == UIDeviceOrientationPortraitUpsideDown) {
        return YES;
    }
    return NO;

}

-(NSUInteger)supportedInterfaceOrientations{
    return (UIInterfaceOrientationMaskPortrait | UIInterfaceOrientationMaskPortraitUpsideDown);
}

-(UIInterfaceOrientation)preferredInterfaceOrientationForPresentation{
    UIDevice* device = [UIDevice currentDevice];
    if (device.orientation == UIInterfaceOrientationPortraitUpsideDown) {
        return UIInterfaceOrientationPortraitUpsideDown;
    }
    return UIInterfaceOrientationPortrait;
}

@end
