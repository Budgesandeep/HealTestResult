//
//  HCapturedGalleryViewController.h
//  Healogics
//
//  Created by Healogics on 12/04/17.
//  Copyright © 2017 Cognizant. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HImageCell.h"
#import "HConstants.h"
#import "HCache.h"
#import "HFFIClass.h"


@interface HCapturedGalleryViewController : UIViewController<UICollectionViewDelegate,UICollectionViewDataSource,CollectionViewCustomCellDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>

@property (strong, nonatomic) IBOutlet UICollectionView *collectionVwCapturedImages;
@property (strong, nonatomic) IBOutlet  UIImageView *imgFull;
@property (strong, nonatomic) IBOutlet  UIView *vwFullImage,*vwFullTransBg;

-(IBAction)btnRetakePhotoClick:(id)sender;
-(IBAction)btnUsePhotoClick:(id)sender;
-(IBAction)btnCloseVwFullImageClick:(id)sender;
-(IBAction)btnBackToKonyForm:(id)sender;

@end
