//
//  HCapturedGalleryViewController.h
//  Healogics
//
//  Created by Healogics on 12/04/17.
//  Copyright © 2017 Cognizant. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <PhotosUI/PhotosUI.h>

// Custom delegate method to remove Cell
@protocol CollectionViewCustomCellDelegate

-(void)deleteSelectedCell:(NSInteger)cellIndexValue;

@end

@interface HImageCell : UICollectionViewCell

@property (retain, nonatomic) IBOutlet UIImageView *imgPhoto;
@property (retain, nonatomic) IBOutlet UIButton *btnDelete;
@property (nonatomic, weak) id <CollectionViewCustomCellDelegate> delegate;

-(IBAction)btnDeleteCapturedPhoto:(id)sender;

@end
