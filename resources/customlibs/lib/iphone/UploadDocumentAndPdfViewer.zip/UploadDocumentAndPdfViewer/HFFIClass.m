//
//  HFFIClass.m
//  Healogics
//
//  Created by Healogics on 17/04/17.
//  Copyright © 2017 Cognizant. All rights reserved.
//

#import "HFFIClass.h"

@implementation HFFIClass

//Creation of Shared Instance
+ (id)sharedManager{
    static HFFIClass *sharedMyManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedMyManager = [[self alloc] init];
    });
    return sharedMyManager;
}

//Method used to open Storyboard from Kony Form
-(void)openNativeiOSCamera:(CallBack*) callbackfunction{
    
    [[HCache sharedManager] clearAllCachedImages];
    UIStoryboard *storyBoard  =  [UIStoryboard storyboardWithName:kStoryboardMain bundle:nil];
    UINavigationController *navVC = [storyBoard instantiateInitialViewController];
    [KonyUIContext onCurrentFormControllerPresentModalViewController:navVC animated:NO];
    self.konyCallBackFunctionName = callbackfunction;

}

-(void)showPDFViewer:(NSString*)strBase64
{
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:kPdfViewer bundle:nil];
    UINavigationController *navVC = [storyBoard instantiateInitialViewController];
    HPdfShareViewController *hPdfVc = (HPdfShareViewController *)[[navVC viewControllers]firstObject];
    hPdfVc.strPdfBase64 = strBase64;
    [[NSOperationQueue mainQueue] addOperationWithBlock:^ {
        NSLog(@"Main Thread Code");
        [[[UIApplication sharedApplication] delegate].window.rootViewController presentViewController:navVC animated:YES completion:nil];
    }];
}
    
-(void)deleteAllCachedImages{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *strPath = [paths objectAtIndex:0];
    NSString *strStoredSmallImagePath = [NSString stringWithFormat:@"%@/%@", strPath,@"Small"];
    NSArray *files = [fileManager contentsOfDirectoryAtPath:strStoredSmallImagePath error:nil];
//    NSLog(@"----- files -----:%@",files.description);
//    NSLog(@"----- files length -----:%lu",(unsigned long)files.count);
    [files enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSString *strPath = [strStoredSmallImagePath stringByAppendingPathComponent:obj];
        [fileManager removeItemAtPath:strPath error:nil];
        strPath = [strPath stringByReplacingOccurrencesOfString:@"Small" withString:@"Large"];
        [fileManager removeItemAtPath:strPath error:nil];
    }];
}

@end
