//
//  HCapturedGalleryViewController.m
//  Healogics
//
//  Created by Healogics on 12/04/17.
//  Copyright © 2017 Cognizant. All rights reserved.
//

#import "HCapturedGalleryViewController.h"

@interface HCapturedGalleryViewController ()

@property (weak, nonatomic) NSMutableArray *arrCapturedImages,*mutArrTempToReorder;
@property (weak, nonatomic) UIAlertController *alert;
@property (weak, nonatomic) NSString *strLargeImgPath;

@end

@implementation HCapturedGalleryViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //Set Font & text color for ViewController's navigation bar Title
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor darkGrayColor], NSFontAttributeName:[UIFont fontWithName:@"Calibri-bold" size:20]}];
    [[UIBarButtonItem appearance] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIFont fontWithName:@"Calibri" size:18.0],NSFontAttributeName, nil] forState:UIControlStateNormal];
    //Initially hide full view of selected Image
    self.vwFullImage.hidden=YES;
    self.vwFullTransBg.hidden=YES;

    //Register Custom UICollectionViewCell HImageCell
    UINib *nib = [UINib nibWithNibName:@"HImageCell" bundle: nil];
    [self.collectionVwCapturedImages registerNib:nib forCellWithReuseIdentifier:@"HImageCell"];
    
    //Add Long press gresture to collection view
    UILongPressGestureRecognizer *longGR = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(handleLongPressOnCollectionView:)];
    [self.collectionVwCapturedImages addGestureRecognizer:longGR];
    
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
    self.arrCapturedImages =[[HCache sharedManager] getAllCachedImages];
    [self.collectionVwCapturedImages reloadData];
}
    
#pragma UINavigationController delegate methods
-(BOOL)shouldAutorotate{
    return NO;
}

-(UIInterfaceOrientationMask)supportedInterfaceOrientations{
    if (kDeviceType == UIUserInterfaceIdiomPad) {
        return UIInterfaceOrientationMaskLandscape;
    }else{
        return UIInterfaceOrientationMaskPortraitUpsideDown;
    }
}

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation
{
    if (kDeviceType == UIUserInterfaceIdiomPad) {
        return (UIInterfaceOrientationLandscapeLeft | UIInterfaceOrientationLandscapeRight);
    }else{
        return UIInterfaceOrientationPortraitUpsideDown;
    }
}

#pragma mark - UICollectionView Delegate methods
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    //return no. of Captured images as number of cells for UICollectionView
    return self.arrCapturedImages.count;
}

- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    HImageCell *cellImage = (HImageCell*)[self.collectionVwCapturedImages dequeueReusableCellWithReuseIdentifier:@"HImageCell" forIndexPath:indexPath];
    __weak __typeof(cellImage)cell = cellImage;
    cell.delegate = self;
    cell.imgPhoto.image = [UIImage imageWithContentsOfFile:[self.arrCapturedImages objectAtIndex:indexPath.row]];
    cell.tag = indexPath.row;
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView moveItemAtIndexPath:(NSIndexPath *)sourceIndexPath toIndexPath:(NSIndexPath*)destinationIndexPath{
    [self reorderCachedImagesArrayElements:sourceIndexPath.row destinationIndex:destinationIndexPath.row];
    [self.arrCapturedImages enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSIndexPath *path = [NSIndexPath indexPathForRow:idx inSection:0];
        HImageCell *cell =(HImageCell*)[self.collectionVwCapturedImages cellForItemAtIndexPath:path];
        cell.tag = idx;
    }];
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    self.vwFullImage.hidden=NO;
    self.vwFullTransBg.hidden=NO;
    self.strLargeImgPath = [self.arrCapturedImages objectAtIndex:indexPath.row];
    self.strLargeImgPath = [self.strLargeImgPath stringByReplacingOccurrencesOfString:strSmallTxt withString:strLargeTxt];
    self.imgFull.image = [UIImage imageWithContentsOfFile:self.strLargeImgPath];
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    //Set differenrt cell sizes for iPad and iPhone
    CGSize screenSize = UIScreen.mainScreen.bounds.size;
    if (kDeviceType == UIUserInterfaceIdiomPad)
    {
        return CGSizeMake((screenSize.width-15)/5, (screenSize.height-15)/5);
    }
    else
    {
        return CGSizeMake((screenSize.width-15)/4, (screenSize.height-15)/6);
    }
}

#pragma mark - support methods
- (void)handleLongPressOnCollectionView:(UILongPressGestureRecognizer *)gesture{
    switch(gesture.state){
        case UIGestureRecognizerStateBegan:
        {
            NSIndexPath *selectedIndexPath = [self.collectionVwCapturedImages indexPathForItemAtPoint:[gesture locationInView:self.collectionVwCapturedImages]];
            if(selectedIndexPath == nil) break;
            [self.collectionVwCapturedImages beginInteractiveMovementForItemAtIndexPath:selectedIndexPath];
            break;
        }
        case UIGestureRecognizerStateChanged:
        {
            [self.collectionVwCapturedImages updateInteractiveMovementTargetPosition:[gesture locationInView:gesture.view]];
            break;
        }
        case UIGestureRecognizerStateEnded:
        {
            [self.collectionVwCapturedImages endInteractiveMovement];
            break;
        }
        default:
        {
            [self.collectionVwCapturedImages cancelInteractiveMovement];
            break;
        }
    }
}

-(void)deleteSelectedCell:(NSInteger)cellIndexValue{
    [self.collectionVwCapturedImages performBatchUpdates:^{
        NSString *strPath = self.arrCapturedImages[cellIndexValue];
        [[HCache sharedManager] deleteSelectedImageFromCache:strPath];
        [self.arrCapturedImages removeObjectAtIndex:cellIndexValue];
        NSIndexPath *indexPath =[NSIndexPath indexPathForRow:cellIndexValue inSection:0];
        [self.collectionVwCapturedImages deleteItemsAtIndexPaths:[NSArray arrayWithObject:indexPath]];
    } completion:^(BOOL finished) {
        [self.collectionVwCapturedImages reloadData];
    }];
}


-(IBAction)btnRetakePhotoClick:(id)sender{
    
    if(self.arrCapturedImages.count>=20){
        self.alert = [UIAlertController alertControllerWithTitle:@"Info" message:@"You have reached the maximum number of pages allowed for file uploads (20)." preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *okAction =[UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            self.alert = nil;
            [self.alert release];
        }];
        [self.alert addAction:okAction];
        [self presentViewController:self.alert animated:NO completion:nil];
    }else{
        //show camera
        [self.navigationController popViewControllerAnimated:NO];
    }
}

-(IBAction)btnUsePhotoClick:(id)sender{
    
    if(self.arrCapturedImages.count==0){
        self.alert = [UIAlertController alertControllerWithTitle:@"Info" message:@"No Documents to upload." preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *okAction =[UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            self.alert = nil;
            [self.alert release];
        }];
        [self.alert addAction:okAction];
        [self presentViewController:self.alert animated:NO completion:nil];
    }else{
        [self dismissViewControllerAnimated:NO completion:nil];
        NSMutableDictionary *mutDictEncodedImages = [[NSMutableDictionary alloc]init];
        [self.arrCapturedImages enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            NSString *strCachedImagePath = [self.arrCapturedImages[idx] stringByReplacingOccurrencesOfString:strSmallTxt withString:strLargeTxt];
            [mutDictEncodedImages setObject:[NSString stringWithFormat:@"%@",strCachedImagePath] forKey:[NSString stringWithFormat:@"%lu",(unsigned long)idx]];
        }];
        
        //This is the way to execute Kony call back method
        HFFIClass *konyCallBack = [HFFIClass sharedManager];
        [konyCallBack.konyCallBackFunctionName executeWithArguments:[NSArray arrayWithObjects:mutDictEncodedImages, nil]];
        [[HCache sharedManager] clearAllCachedSmallImages];

    }

}

-(IBAction)btnCloseVwFullImageClick:(id)sender{
    self.vwFullImage.hidden=YES;
    self.vwFullTransBg.hidden=YES;
}

-(IBAction)btnBackToKonyForm:(id)sender{
    
    [self dismissViewControllerAnimated:NO completion:nil];
    //call kony call back function
    HFFIClass *konyCallBack = [HFFIClass sharedManager];
    [konyCallBack.konyCallBackFunctionName executeWithArguments: nil];
}

-(void)reorderCachedImagesArrayElements:(NSInteger)sourceIndex destinationIndex:(NSInteger)destinationIndex{
    
    self.mutArrTempToReorder = nil;
    self.mutArrTempToReorder = [[NSMutableArray alloc]init];
    [self.arrCapturedImages enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if (idx==destinationIndex){
            [self.mutArrTempToReorder addObject:self.arrCapturedImages[sourceIndex]];
        }else{
            if(sourceIndex>destinationIndex){
                if(idx<destinationIndex || idx>sourceIndex){
                    [self.mutArrTempToReorder addObject:self.arrCapturedImages[idx]];
                }else{
                    [self.mutArrTempToReorder addObject:self.arrCapturedImages[idx-1]];
                }
            }else{
                if(idx<sourceIndex || idx>destinationIndex){
                    [self.mutArrTempToReorder addObject:self.arrCapturedImages[idx]];
                }else{
                    [self.mutArrTempToReorder addObject:self.arrCapturedImages[idx+1]];
                }
            }
        }
        
    }];
    //NSLog(@"reorderCachedImagesArrayElements : %@",tempArr.description);
    [self.arrCapturedImages removeAllObjects];
    self.arrCapturedImages = self.mutArrTempToReorder;
}

    
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    NSLog(@"--- received memory warning ---- ");
}
    


@end
