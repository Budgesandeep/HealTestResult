//
//  HFFIClass.h
//  Healogics
//
//  Created by Healogics on 17/04/17.
//  Copyright © 2017 Cognizant. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "CallBack.h"
#import "HCapturedGalleryViewController.h"
#import "HPdfShareViewController.h"
#import "KonyUIContext.h"
#import "HCache.h"

@interface HFFIClass : NSObject

@property (nonatomic, strong) CallBack *konyCallBackFunctionName;

+ (id)sharedManager;
-(void)openNativeiOSCamera:(CallBack*) callbackfunction;
-(void)showPDFViewer:(NSString*)strBase64;
-(void)deleteAllCachedImages;
    
@end
