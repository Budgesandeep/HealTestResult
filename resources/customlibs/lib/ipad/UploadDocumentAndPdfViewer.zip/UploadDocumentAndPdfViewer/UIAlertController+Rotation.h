//
//  UIAlertController+Rotation.h
//  VMAppWithKonylib
//
//  Created by Healogics on 19/06/17.
//
//

#import <UIKit/UIKit.h>

@interface UIAlertController (Rotation)



@end

