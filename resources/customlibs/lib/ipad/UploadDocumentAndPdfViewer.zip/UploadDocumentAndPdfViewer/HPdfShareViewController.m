//
//  ViewController.m
//  vDocsViewer
//
//  Created by Priteesh on 25/02/17.
//  Copyright © 2017 Priteesh. All rights reserved.
//

#import "HPdfShareViewController.h"

#define FOLDERNAME @"Wound360"

@interface HPdfShareViewController ()<UIWebViewDelegate>

@end

@implementation HPdfShareViewController

@synthesize strPdfBase64;

- (void)viewDidLoad {
    [super viewDidLoad];

//    NSLog(@"----- Base 64 string length ---- : %lu",(unsigned long)strPdfBase64.length);
    
    self.webview.delegate = self;
    NSData *data = [[NSData alloc]initWithBase64EncodedString:strPdfBase64 options:0];
    [self.webview loadData:data MIMEType:@"application/pdf" textEncodingName:@"UTF-8" baseURL:nil];

    [self shareButtonTapped:nil];

}

- (IBAction)backButtonTapped:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)shareButtonTapped:(id)sender {
    
    [self.loadingIndicator startAnimating];
    self.view.userInteractionEnabled = false;
    NSData *data = [[NSData alloc]initWithBase64EncodedString:strPdfBase64 options:0];
    [self shareFileWithData:data andFileName:@"Report" andExtension:@"pdf"];
    
}


-(void)webViewDidStartLoad:(UIWebView *)webView {
    self.view.userInteractionEnabled = false;
    [self.loadingIndicator startAnimating];
}

-(void)webViewDidFinishLoad:(UIWebView *)webView {
    self.view.userInteractionEnabled = true;
    [self.loadingIndicator stopAnimating];
    [self.loadingIndicator setHidesWhenStopped:YES];
}


-(void)shareUrl:(NSURL*)url{
    
    dispatch_async(dispatch_get_main_queue(), ^{
        // do work here
        
        NSArray *objectsToShare = @[url];
        
        UIActivityViewController *controller = [[UIActivityViewController alloc] initWithActivityItems:objectsToShare applicationActivities:nil];
        
        // Exclude all activities except Print.
        NSArray *excludedActivities = @[  UIActivityTypePostToFacebook,
                                                           UIActivityTypePostToTwitter,
                                                           UIActivityTypePostToWeibo,
                                                           UIActivityTypeMessage,
                                                           UIActivityTypeMail,
                                                           UIActivityTypeCopyToPasteboard,
                                                           UIActivityTypeAssignToContact,
                                                           UIActivityTypeSaveToCameraRoll,
                                                           UIActivityTypeAddToReadingList,
                                                           UIActivityTypePostToFlickr,
                                                           UIActivityTypePostToVimeo,
                                                           UIActivityTypePostToTencentWeibo,
                                                           UIActivityTypeAirDrop,
                                                           UIActivityTypeOpenInIBooks
                                               ];
        controller.excludedActivityTypes = excludedActivities;
        
        controller.popoverPresentationController.sourceView = self.view;
        
        // Present the controller
        [self presentViewController:controller animated:YES completion:^(){
            //put your code here
            self.view.userInteractionEnabled = true;
            [self.loadingIndicator stopAnimating];
            [self.loadingIndicator setHidesWhenStopped:YES];
        }];
    });
}


- (void)shareFileWithData:(NSData*)data andFileName:(NSString*)fileName andExtension:(NSString*)extension {
    NSString *filePath = [self saveFileWithData:data andFileName:fileName andExtension:extension];
    [self shareUrl:[self filePathURLFromFilePath:filePath]];
}

// Save File Which is having data
- (NSString*)saveFileWithData:(NSData*)data andFileName:(NSString*)fileName andExtension:(NSString*)extension {
    NSString *tmpDir = NSTemporaryDirectory();
    //    NSString *documentsDirectory = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
    NSString *path = [tmpDir stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.%@",fileName, extension]];
    [data writeToFile:path atomically:YES];
    
    NSString *folderPath = [[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)objectAtIndex:0]stringByAppendingPathComponent:FOLDERNAME];
    NSError *error = nil;
    if (![[NSFileManager defaultManager] fileExistsAtPath:folderPath]) {
        [[NSFileManager defaultManager] createDirectoryAtPath:folderPath withIntermediateDirectories:NO attributes:nil error:&error];
    }
    //log error
    
    NSString *filePath = [folderPath stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.%@",fileName,extension]];
    [data writeToFile:filePath atomically:YES];
    return filePath;
}

- (NSURL*)filePathURLFromFilePath:(NSString*)filePath {
    
    return [NSURL fileURLWithPath:filePath isDirectory:NO];
    
}

-(BOOL)shouldAutorotate{
    return NO;
}

-(UIInterfaceOrientationMask)supportedInterfaceOrientations{
    return UIInterfaceOrientationMaskLandscape;
}

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation
{
    return (UIInterfaceOrientationLandscapeLeft | UIInterfaceOrientationLandscapeRight);
}

- (void)dealloc {
    [_loadingIndicator release];
    [super dealloc];
}
@end
