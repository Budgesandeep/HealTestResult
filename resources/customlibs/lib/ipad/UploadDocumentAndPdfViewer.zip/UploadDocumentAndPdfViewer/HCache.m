//
//  Cache.m
//  VMAppWithKonylib
//
//  Created by Healogics on 16/06/17.
//
//

#import "HCache.h"

@implementation HCache

+ (id)sharedManager
{
    static HCache *sharedMyManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedMyManager = [[self alloc] init];
    });
    return sharedMyManager;
}
    
-(NSString*)checkAndGetMeCacheDirectoryPath : (NSString*)type
{
    self.fileManager = [NSFileManager defaultManager];
    self.paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    self.strStoredSmallImagePath = [NSString stringWithFormat:@"%@/%@", [self.paths objectAtIndex:0], strSmallTxt];
    self.strStoredLargeImagePath = [NSString stringWithFormat:@"%@/%@", [self.paths objectAtIndex:0], strLargeTxt];
    NSString *path = ([type isEqualToString:strSmallTxt]) ? self.strStoredSmallImagePath : self.strStoredLargeImagePath ;
    //NSLog (@"----- path ----- : %@",path);
    NSString *currentpath = [self.fileManager currentDirectoryPath];
    if ([self.fileManager changeCurrentDirectoryPath: path] == NO)
    {
       // NSLog (@"Cannot change directory.");
        NSURL *newDir = [NSURL fileURLWithPath:path];
        [self.fileManager createDirectoryAtURL: newDir withIntermediateDirectories:YES attributes: nil error:nil];
        if ([self.fileManager changeCurrentDirectoryPath: path] == YES)
        {
           // NSLog (@"Changed directory.");
        }
    }
    currentpath = [self.fileManager currentDirectoryPath];
       // NSLog (@"Current directory is %@", currentpath);
    __block NSString *lastWord = nil;
    [currentpath enumerateSubstringsInRange:NSMakeRange(0, [currentpath length]) options:NSStringEnumerationByWords | NSStringEnumerationReverse usingBlock:^(NSString *substring, NSRange subrange, NSRange enclosingRange, BOOL *stop) {
        lastWord = substring;
        *stop = YES;
    }];
    return currentpath;
}

- (void)cacheImage: (NSString *)ImageURLString andImage:(UIImage*)img type:(NSString*)type{
    NSString *filename     = [self checkAndGetMeCacheDirectoryPath:type];
    NSString *uniquePath = [filename stringByAppendingPathComponent: ImageURLString];
    if(![self.fileManager fileExistsAtPath: uniquePath])  
    {
        [UIImageJPEGRepresentation(img, maxCompressionLevel) writeToFile: [NSString stringWithFormat:@"%@.jpeg",uniquePath] atomically: YES];
    }
    else
    {
          //NSLog(@"Already there is a cached image with id : %@",ImageURLString);
    }
    img = nil;
}


-(NSMutableArray*)getAllCachedImages{
    
    NSMutableArray *mutArrCachedImages = [[NSMutableArray alloc]init];
    self.fileManager = [NSFileManager defaultManager];
    self.paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    self.strStoredSmallImagePath = [NSString stringWithFormat:@"%@/%@", [self.paths objectAtIndex:0], strSmallTxt];
    self.strStoredLargeImagePath = [NSString stringWithFormat:@"%@/%@", [self.paths objectAtIndex:0], strLargeTxt];
    self.arrCachedfiles = [self.fileManager contentsOfDirectoryAtPath:self.strStoredSmallImagePath error:nil];
    [self.arrCachedfiles enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSString *imagePath = [self.strStoredSmallImagePath stringByAppendingPathComponent:obj];
        [mutArrCachedImages addObject:imagePath];
    }];
    //NSLog(@"mutArrCachedImages----->>>>:%@",mutArrCachedImages);
    return mutArrCachedImages;

}
    
-(void)clearAllCachedImages{

    [[self getAllCachedImages] enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSString *strPath = obj;
        [self.fileManager removeItemAtPath:strPath error:nil];
        strPath = [strPath stringByReplacingOccurrencesOfString:strSmallTxt withString:strLargeTxt];
        [self.fileManager removeItemAtPath:strPath error:nil];
    }];
}

-(void)deleteSelectedImageFromCache:(NSString*)strPath{
    
   // NSLog(@"----- strPath -----:%@",strPath);
    [self.fileManager removeItemAtPath:strPath error:nil];
    strPath = [strPath stringByReplacingOccurrencesOfString:strSmallTxt withString:strLargeTxt];
   // NSLog(@"----- strPath Large-----:%@",strPath);
    [self.fileManager removeItemAtPath:strPath error:nil];
    
}
    
-(void)clearAllCachedSmallImages{

    [[self getAllCachedImages] enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [self.fileManager removeItemAtPath:obj error:nil];
    }];
}
    
@end
