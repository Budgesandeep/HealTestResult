//
//  UINavigationController+deviceOrientation.m
//  VMAppWithKonylib
//
//  Created by Healogics on 17/05/17.
//
//

#import "UINavigationController+deviceOrientation.h"

@implementation UINavigationController (deviceOrientation)

-(BOOL)shouldAutorotate{
    return [[self.viewControllers lastObject] shouldAutorotate];
}

-(UIInterfaceOrientationMask)supportedInterfaceOrientations{
    return [[self.viewControllers lastObject] supportedInterfaceOrientations];
}

-(UIInterfaceOrientation)preferredInterfaceOrientationForPresentation{
    return [[self.viewControllers lastObject] preferredInterfaceOrientationForPresentation];
}

@end
