//
//  TSCapturePhotoViewController.h
//  VMAppWithKonylib
//
//  Created by Healogics on 27/09/16.
//  Copyright © 2016 Cognizant. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HCache.h"
#import "HFFIClass.h"
#import "UIImage+Resize.h"
#import "HCapturedGalleryViewController.h"

@interface HCaptureViewController : UIViewController

-(IBAction)btnBackToKonyForm:(id)sender;
- (IBAction)btnRetakePhotoClick:(id)sender;
- (IBAction)btnUsePhotoClick:(id)sender;
- (IBAction)btnCacelCameraClick:(id)sender;

    
@end

