//
//  ViewController.h
//  vDocsViewer
//
//  Created by Priteesh on 25/02/17.
//  Copyright © 2017 Priteesh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface HPdfShareViewController : UIViewController
{
//    NSString * thisStr;
}
@property(nonatomic,strong) NSString *strPdfBase64;
@property (weak, nonatomic) IBOutlet UIWebView *webview;
@property (retain, nonatomic) IBOutlet UIActivityIndicatorView *loadingIndicator;


@end

